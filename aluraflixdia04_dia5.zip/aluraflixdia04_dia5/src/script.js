function adicionarFilme(){
  var campoFilme = document.querySelector('#filme')  
  var filme = campoFilme.value
  console.log(filme)
}