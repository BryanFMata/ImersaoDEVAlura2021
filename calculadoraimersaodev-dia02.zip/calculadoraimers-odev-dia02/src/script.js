var primValor = parseInt(prompt("Digite o primeiro valor:"))
var segValor = parseInt(prompt("Digite o segundo valor:"))
var operacao = parseInt(prompt("Digite 1 para soma, 2 para subtração, 3 para multiplicação e 4 para divisão"))
switch(operacao){
  case 1:
    var resultado = primValor + segValor
    document.write("<h2>" + primValor + " + " + segValor + " = " +    resultado + "</h2>")
    break
  case 2:
    var resultado = primValor - segValor
    document.write("<h2>" + primValor + " - " + segValor + " = " +  resultado + "</h2>")
    break
  case 3:
    var resultado = primValor * segValor
    document.write("<h2>" + primValor + " X " + segValor + " = " +  resultado + "</h2>")
    break
  case 4:
    var resultado = primValor / segValor
    document.write("<h2>" + primValor + " / " + segValor + " = " +  resultado + "</h2>")
    break
  default:
    document.write("<h2>Opção Inválida</h2>")
}

