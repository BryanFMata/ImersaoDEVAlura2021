var valorDolar = parseFloat(prompt("Qual valor voce deseja converter?"))
var valorReal = valorDolar*5.5
valorReal = valorReal.toFixed(2)
alert(valorReal)