var numCerto = parseInt(Math.random() * 10) + 1
var tentativas = 3
while(tentativas){
  var chute = parseInt(prompt("Digite um número entre 0 e 10"))
  if(numCerto == chute){
    alert("Acertou o número!")
    break
  }
  else if(chute > numCerto){
    alert("O número certo é menor!")
  }
  else if(chute < numCerto){
    alert("O número certo é maior!")
  }
  tentativas--;
}